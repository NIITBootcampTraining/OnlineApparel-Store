import { Injectable } from '@angular/core';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Feedback } from '../_models/feedback';

const httpOptions ={
  headers: new HttpHeaders({'Content-Type':'application/json'})
};
@Injectable()
export class FeedbackService {

  constructor(private _Http: HttpClient) { }
  getFeedBack():Observable<Feedback[]>{
    return this._Http.get<Feedback[]>("http://localhost:54638/api/feedback");
  }
  getFeedBackById(id:number):Observable<Feedback>{
    return this._Http.get<Feedback>("http://localhost:54638/api/feedback/"+id);
  } 
}
