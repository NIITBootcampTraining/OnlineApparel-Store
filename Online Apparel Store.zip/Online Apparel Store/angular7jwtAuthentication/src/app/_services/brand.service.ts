import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders} from '@angular/common/http';
import { Observable } from 'rxjs';
import { Brand } from '../_models/brand';
const httpOptions ={
  headers: new HttpHeaders({'Content-Type':'application/json'})
};
@Injectable()
export class BrandService {

  constructor(private _Http: HttpClient) { }
  getBrands():Observable<Brand[]>{
    return this._Http.get<Brand[]>("http://localhost:54638/api/brand");
  }
  getBrandsById(id:number):Observable<Brand>{
    return this._Http.get<Brand>("http://localhost:54638/api/brand/"+id);
  }
  deleteBrands(id:number):Observable<Brand>{
   return this._Http.delete<Brand>("http://localhost:54638/api/brand/"+id);
  }
  addNewBrand(brand:Brand):Observable<Brand>{
    return this._Http.post<Brand>("http://localhost:54638/api/brand/",brand,httpOptions);
   }
   editBrand(id:number, brand:Brand):Observable<Brand>{
    return this._Http.put<Brand>("http://localhost:54638/api/brand/"+id,brand,httpOptions);
   }
}
