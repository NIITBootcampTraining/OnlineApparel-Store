import { Injectable } from '@angular/core';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Order } from '../_models/order';

const httpOptions ={
  headers: new HttpHeaders({'Content-Type':'application/json'})
};
@Injectable()
export class OrderService {

  constructor(private _Http: HttpClient) { }
  getOrder():Observable<Order[]>{
    return this._Http.get<Order[]>("http://localhost:54638/api/order");
  }
  getOrderById(id:number):Observable<Order>{
    return this._Http.get<Order>("http://localhost:54638/api/order/"+id);
  }
  deleteOrder(id:number):Observable<Order>{
   return this._Http.delete<Order>("http://localhost:54638/api/order/"+id);
  }
   editOrder(id:number, order:Order):Observable<Order>{
    return this._Http.put<Order>("http://localhost:54638/api/order/"+id,order,httpOptions);
   }
}
