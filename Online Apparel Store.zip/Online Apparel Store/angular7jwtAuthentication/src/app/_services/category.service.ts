import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders} from '@angular/common/http';
import { Observable } from 'rxjs';
import { Category } from '../_models/category';
const httpOptions ={
  headers: new HttpHeaders({'Content-Type':'application/json'})
};
@Injectable()
export class CategoryService {

  constructor(private _Http: HttpClient) { }
  getCategories():Observable<Category[]>{
    return this._Http.get<Category[]>("http://localhost:54638/api/category");
  }
  getCategoriesById(id:number):Observable<Category>{
    return this._Http.get<Category>("http://localhost:54638/api/category/"+id);
  }
  deleteCategories(id:number):Observable<Category>{
   return this._Http.delete<Category>("http://localhost:54638/api/category/"+id);
  }
  addNewCategory(category:Category):Observable<Category>{
    return this._Http.post<Category>("http://localhost:54638/api/category/",category,httpOptions);
   }
   editCategory(id:number, category:Category):Observable<Category>{
    return this._Http.put<Category>("http://localhost:54638/api/category/"+id,category,httpOptions);
   }
}