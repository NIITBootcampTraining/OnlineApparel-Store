import { Injectable } from '@angular/core';
import { HttpClient} from '@angular/common/http';
import { Observable } from 'rxjs';

import { admin } from '../_models/admin';

@Injectable()
export class AdminService {

  constructor(private _Http: HttpClient) { }
  getAdmin():Observable<admin[]>{
    return this._Http.get<admin[]>("http://localhost:54638/api/admin");
  }
  getAdminById(id:number):Observable<admin>{
    return this._Http.get<admin>("http://localhost:54638/api/admmin/"+id);
  }
  
}
