import { Injectable } from '@angular/core';
import { HttpClient} from '@angular/common/http';
import { Observable } from 'rxjs';
import { payment } from '../_models/payment';

@Injectable()
export class paymentService {

  constructor(private _Http: HttpClient) { }
  getAdmin():Observable<payment[]>{
    return this._Http.get<payment[]>("http://localhost:54638/api/payment");
  }
  getAdminById(id:number):Observable<payment>{
    return this._Http.get<payment>("http://localhost:54638/api/payment/"+id);
  }
  
}
