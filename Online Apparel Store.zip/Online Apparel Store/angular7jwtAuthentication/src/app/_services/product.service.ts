import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders} from '@angular/common/http';
import { Observable } from 'rxjs';
import { Product } from '../_models/product';
const httpOptions ={
  headers: new HttpHeaders({'Content-Type':'application/json'})
};
@Injectable()
export class ProductService {

  constructor(private _Http: HttpClient) { }
  getProducts():Observable<Product[]>{
    return this._Http.get<Product[]>("http://localhost:54638/api/product");
  }
  getProductsById(id:number):Observable<Product>{
    return this._Http.get<Product>("http://localhost:54638/api/product/"+id);
  }
  deleteProducts(id:number):Observable<Product>{
   return this._Http.delete<Product>("http://localhost:54638/api/product/"+id);
  }
  addNewProduct(product:Product):Observable<Product>{
    return this._Http.post<Product>("http://localhost:54638/api/product/",product,httpOptions);
   }
   editProduct(id:number, product:Product):Observable<Product>{
    return this._Http.put<Product>("http://localhost:54638/api/product/"+id,product,httpOptions);
   }
}