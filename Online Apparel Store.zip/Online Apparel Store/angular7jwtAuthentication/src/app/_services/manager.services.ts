import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders} from '@angular/common/http';
import { Observable } from 'rxjs';
import { Brand } from '../_models/brand';
import { manager } from '../_models/manager';
const httpOptions ={
  headers: new HttpHeaders({'Content-Type':'application/json'})
};
@Injectable()
export class ManagerService {

  constructor(private _Http: HttpClient) { }
  getManager():Observable<manager[]>{
    return this._Http.get<manager[]>("http://localhost:54638/api/manager");
  }
  getManagerById(id:number):Observable<manager>{
    return this._Http.get<manager>("http://localhost:54638/api/manager/"+id);
  }
  deleteManager(id:number):Observable<manager>{
   return this._Http.delete<manager>("http://localhost:54638/api/manager/"+id);
  }
  addNewManager(brand:manager):Observable<manager>{
    return this._Http.post<manager>("http://localhost:54638/api/manager/",brand,httpOptions);
   }
   editManager(id:number, brand:manager):Observable<manager>{
    return this._Http.put<manager>("http://localhost:54638/api/manager/"+id,brand,httpOptions);
   }
}
