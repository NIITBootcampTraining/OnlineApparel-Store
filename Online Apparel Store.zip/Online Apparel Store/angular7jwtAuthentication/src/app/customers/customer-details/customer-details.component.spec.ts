import{async,ComponentFixture,TestBed, inject} from '@angular/core/testing';
import{CustomerDetailsComponent} from './customer-details.component';
import {RouterTestingModule} from '@angular/router/testing';
import { HttpClientModule } from '@angular/common/http';
import { ReactiveFormsModule } from '@angular/forms';
import { CustomerService } from 'src/app/_services/customer.service';
describe('Testing Customer-Details Component', () => {
    let component: CustomerDetailsComponent;
    let fixture: ComponentFixture<CustomerDetailsComponent>;
    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [CustomerDetailsComponent],
            imports: [RouterTestingModule,HttpClientModule,ReactiveFormsModule],
            providers: [CustomerService]
        }).compileComponents();
    }));
    beforeEach(()=>{
        fixture = TestBed.createComponent(CustomerDetailsComponent);
        component = fixture.componentInstance;
    })
    it('should create', async(() => {     
        expect(component).toBeTruthy();
    }));
//     it('Retrieves Customer by ID',async(inject([CustomerService],(customerServie)=>{
//         customerServie.getCustomerById(2).subscribe(result=>{           
//             console.log("Customer with ID 2");
            
//        })  
//    })));
})
