import { Component, OnInit } from '@angular/core';
import { CustomerService } from 'src/app/_services/customer.service';
import { Customer } from 'src/app/_models/customer';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-customer-details',
  templateUrl: './customer-details.component.html',
  styleUrls: ['./customer-details.component.css'],
  providers:[CustomerService]
})
export class CustomerDetailsComponent implements OnInit {

  id: number;
  customer:Customer=new Customer();
  constructor(private route: ActivatedRoute, private cat: CustomerService,private router:Router) { }

  ngOnInit() {
    this.route.params.subscribe(param => {
      this.id = +param['id'];
      this.cat.getCustomerById(this.id).subscribe(result => {
        this.customer = result;
        console.log(result);
      })
    });
  }
  deleteExistingCustomer(id: number) {
    this.cat.deleteCustomer(id).subscribe(result => {
      console.log("Customer Deleted Successfully");
      this.router.navigate(['/customer']);
    })
  }

}
