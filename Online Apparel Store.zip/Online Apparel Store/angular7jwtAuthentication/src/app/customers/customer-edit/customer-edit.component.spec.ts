import{async,ComponentFixture,TestBed, inject} from '@angular/core/testing';
import{CustomerEditComponent} from './customer-edit.component';
import {RouterTestingModule} from '@angular/router/testing';
import { HttpClientModule } from '@angular/common/http';
import { ReactiveFormsModule } from '@angular/forms';
import { CustomerService } from 'src/app/_services/customer.service';
import { Customer } from 'src/app/_models/customer';
describe('Testing Customer-Edit Component', () => {
    let component: CustomerEditComponent;
    let fixture: ComponentFixture<CustomerEditComponent>;
    let cus:Customer =new Customer()
    {
        cus.customerFirstName="Shivani",
        cus.customerLastName="Diwedi",
        cus.email="shivi@gmail.com",
        cus.password="shivani",
        cus.customerId=2,
        cus.userName="Shivi",
        cus.address="Noida sector Near me",
        cus.state="Uttar Pradesh",
        cus.country="India",
        cus.zipCode=201305,
        cus.gender="Female"
    }; 
    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [CustomerEditComponent],
            imports: [RouterTestingModule,HttpClientModule,ReactiveFormsModule],
            providers: [CustomerService]
        }).compileComponents();
    }));
    beforeEach(()=>{
        fixture = TestBed.createComponent(CustomerEditComponent);
        component = fixture.componentInstance;
    })
    it('should create', async(() => {     
        expect(component).toBeTruthy();
    }));
     it('Edit Customer',async(inject([CustomerService],(customerServie)=>{
        customerServie.editCustomer(2,cus).subscribe(result=>{         
           console.log("Customer Updated successfully");          
         })  
    })));
})
