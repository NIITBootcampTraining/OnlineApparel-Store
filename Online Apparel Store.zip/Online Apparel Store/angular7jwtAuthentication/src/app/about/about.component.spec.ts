import {AboutComponent} from './about.component';
import { from } from "rxjs";

describe('Testing Addition',()=>{
    var component
    beforeAll(()=>{
        console.log('Addition');
     component=new AboutComponent();
    })
it('Testing Positive Numbers',()=>{
   expect(component.add(4,5)).toEqual(9);
});
it('Testing Negative Numbers',()=>{
   expect(component.add(-4,-5)).toEqual(-9);
});
afterAll(()=>{
   //write a cleanup code
  })

})

describe('Testing Subtract',()=>{
    var component
    beforeAll(()=>{
        console.log('Subraction');
     component=new AboutComponent();
    })
it('Testing Subtract-1',()=>{
    expect(component.subtract(-4,-5)).toEqual(1);
 });
 it('Testing Subtract-2',()=>{
    expect(component.subtract(400,300)).toEqual(100);
 });
 afterAll(()=>{
    //write a cleanup code
   })
})

describe('Testing About Component',()=>{
    var component
    beforeAll(()=>{
     component=new AboutComponent();
    })
    it('Testing Title',()=>{
         expect(component.title).toBe("About Component");
    })
    afterAll(()=>{
        //write a cleanup code
       })
})