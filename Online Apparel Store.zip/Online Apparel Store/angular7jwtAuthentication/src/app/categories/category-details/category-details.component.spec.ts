import{async,ComponentFixture,TestBed, inject} from '@angular/core/testing';
import{CategoryDetailsComponent} from './category-detail.component';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientModule } from '@angular/common/http';
import { ReactiveFormsModule } from '@angular/forms';
import { CategoryService } from 'src/app/_services/category.service';

describe('Testing Category-Details',()=>{
    let component:CategoryDetailsComponent;
    let fixture:ComponentFixture<CategoryDetailsComponent>;
    beforeEach(async()=>{
       TestBed.configureTestingModule({
           declarations:[CategoryDetailsComponent],
           imports:[RouterTestingModule,HttpClientModule,ReactiveFormsModule],
           providers:[CategoryService]
       }).compileComponents();
    });
    beforeEach(()=>{
        fixture=TestBed.createComponent(CategoryDetailsComponent);
        component=fixture.componentInstance;
    });
    it('should create', async(() => {     
        expect(component).toBeTruthy();
    }));
    it('Retrieves Category by ID',async(inject([CategoryService],(categoryServie)=>{
        categoryServie.getCategoriesById(7).subscribe(result=>{           
            console.log("Brand with ID 7");
            
       })  
   })));
})