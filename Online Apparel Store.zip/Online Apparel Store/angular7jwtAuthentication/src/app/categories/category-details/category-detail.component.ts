import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CategoryService } from 'src/app/_services/category.service';
import { Category } from 'src/app/_models/category';


@Component({
  selector: 'app-category-detail',
  templateUrl: './category-detail.component.html',
  styleUrls: ['./category-detail.component.css'],
  providers: [CategoryService]
})
export class CategoryDetailsComponent implements OnInit {

  id: number;
  category: Category = new Category();
  constructor(private route: ActivatedRoute, private cat: CategoryService,private router:Router) { }

  ngOnInit() {
    this.route.params.subscribe(param => {
      this.id = +param['id'];
      this.cat.getCategoriesById(this.id).subscribe(result => {
        this.category = result;
        console.log(result);
      })
    });
  }
  deleteExistingCategory(id: number) {
    this.cat.deleteCategories(id).subscribe(result => {
      console.log("Category Deleted Successfully");
      this.router.navigate(['/category']);
    })
  }
}

