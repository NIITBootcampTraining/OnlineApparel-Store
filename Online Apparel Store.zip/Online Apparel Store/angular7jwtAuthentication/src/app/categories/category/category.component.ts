import { Component, OnInit } from '@angular/core';
import { CategoryService } from 'src/app/_services/category.service';
import { Category } from 'src/app/_models/category';

@Component({
  selector: 'app-category',
  templateUrl: './category.component.html',
  styleUrls: ['./category.component.css'],
  providers: [CategoryService]
})
export class CategoryComponent implements OnInit {

  categories: Category[];
  constructor(private _categories: CategoryService) { }

  ngOnInit() {
    this.getAllCategories()
  }
  getAllCategories() {
    this._categories.getCategories().subscribe(result => {
      this.categories = result;
      console.log(this.categories);
    })
  }
  deleteExistingCategory(id: number) {
    this._categories.deleteCategories(id).subscribe(result => {
      console.log("Category Deleted Successfully");
      this.getAllCategories();

    })
  }
}