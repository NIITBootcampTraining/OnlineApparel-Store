import{async,ComponentFixture,TestBed, inject} from '@angular/core/testing';
import{CategoryComponent} from './category.component';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientModule } from '@angular/common/http';
import { CategoryService } from 'src/app/_services/category.service';

describe('Testing Category-Get',()=>{
    let component:CategoryComponent;
    let fixture:ComponentFixture<CategoryComponent>;
    beforeEach(async()=>{
       TestBed.configureTestingModule({
           declarations:[CategoryComponent],
           imports:[RouterTestingModule,HttpClientModule],
           providers:[CategoryService]
       }).compileComponents();
    });
    beforeEach(()=>{
        fixture=TestBed.createComponent(CategoryComponent);
        component=fixture.componentInstance;
    });
    it('should create', async(() => {     
        expect(component).toBeTruthy();
    }));
    it('Retrieves all Category',async(inject([CategoryService],(categoryService)=>{
        categoryService.getCategories().subscribe(result=>{
            expect(result.length).toEqual(8);
            console.log("Successfully retrieved all categories");
            
        })  
   })));
//    it('Delete specific Category',async(inject([CategoryService],(categoryServie)=>{
//          categoryServie.deleteCategories(9).subscribe(result=>{
//                  console.log('Category deleted successfully');
                
//              })  
//     })));

})