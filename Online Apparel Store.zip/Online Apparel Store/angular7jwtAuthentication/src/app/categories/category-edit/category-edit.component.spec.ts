import{async,ComponentFixture,TestBed, inject} from '@angular/core/testing';
import{CategoryEditComponent} from './category-edit.component';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientModule } from '@angular/common/http';
import { ReactiveFormsModule } from '@angular/forms';
import { Category } from 'src/app/_models/category';
import { CategoryService } from 'src/app/_services/category.service';

describe('Testing Category-Edit',()=>{
    let component:CategoryEditComponent;
    let fixture:ComponentFixture<CategoryEditComponent>;
    let cat:Category =new Category()
    {
        cat.categoryId=11,
        cat.categoryName="Goggles",
        cat.categoryDescription="Goggle's Desc"
    }; 
    beforeEach(async()=>{
       TestBed.configureTestingModule({
           declarations:[CategoryEditComponent],
           imports:[RouterTestingModule,HttpClientModule,ReactiveFormsModule],
           providers:[CategoryService]
       }).compileComponents();
    });
    beforeEach(()=>{
        fixture=TestBed.createComponent(CategoryEditComponent);
        component=fixture.componentInstance;
    });
    it('should create', async(() => {     
        expect(component).toBeTruthy();
    }));
    //   it('Edit Category',async(inject([CategoryService],(brandServie)=>{
    //     brandServie.editCategory(11,cat).subscribe(result=>{         
    //        console.log("Category Updated successfully");          
    //      })  
    // })));
})
