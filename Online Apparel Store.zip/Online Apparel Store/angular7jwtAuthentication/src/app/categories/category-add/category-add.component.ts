import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { CategoryService } from 'src/app/_services/category.service';
import { Category } from 'src/app/_models/category';

@Component({
  selector: 'app-category-add',
  templateUrl: './category-add.component.html',
  styleUrls: ['./category-add.component.css'],
  providers:[CategoryService]
})
export class CategoryAddComponent implements OnInit {
  
  catForm:FormGroup;
  category:Category = new Category();

  constructor(private _cat:CategoryService,private router:Router,private fb:FormBuilder) {
    this.createForm();
   }

  ngOnInit() {
  }
  addNewCategory(){
    this._cat.addNewCategory(this.category).subscribe(result =>{
      console.log(result);
      console.log('Category Added Successfully.');
      this.router.navigate(['/category']);
    });
  }
  createForm(){
    this.catForm=this.fb.group({
      categoryName:['',Validators.required],
      categoryDescription:['',Validators.required]
  })
  }
}
