import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ProductService } from 'src/app/_services/product.service';
import { VendorService } from 'src/app/_services/vendor.service';
import { BrandService } from 'src/app/_services/brand.service';
import { CategoryService } from 'src/app/_services/category.service';
import { Product } from 'src/app/_models/product';
import { Category } from 'src/app/_models/category';
import { Brand } from 'src/app/_models/brand';
import { Vendor } from 'src/app/_models/vendor';


@Component({
  selector: 'app-product-detail',
  templateUrl: './product-detail.component.html',
  styleUrls: ['./product-detail.component.css'],
  providers: [ProductService,VendorService,BrandService,CategoryService]
})
export class ProductDetailsComponent implements OnInit {

  id: number;
  bName:string;
  vName:string;
  cName:string;
  product: Product = new Product();
  category:Category;
  brand:Brand;
   vendor:Vendor;
  constructor(private route: ActivatedRoute, private pr: ProductService,private router:Router,private _category:CategoryService,private _brand:BrandService,private _vendor:VendorService) { }

  ngOnInit() {
    this.route.params.subscribe(param => {
      this.id = +param['id'];
      this.pr.getProductsById(this.id).subscribe(result => {
        this.product = result;
        console.log(result);

        this._category.getCategoriesById(this.product.categoryId).subscribe(result=>{
          console.log(result);
          this.category=result;
          this.cName=this.category.categoryName;});
    
          this._brand.getBrandsById(this.product.brandId).subscribe(result=>{
            console.log(result);
            this.brand=result;
          this.bName=this.brand.brandName});
          
          this._vendor.getVendorsById(this.product.vendorId).subscribe(result=>{
            console.log(result);
            this.vendor=result;
          this.vName=this.vendor.vendorName});
      })
    });
 
  }
  deleteExistingProduct(id: number) {
    this.pr.deleteProducts(id).subscribe(result => {
      console.log("Product Deleted Successfully");
      this.router.navigate(['/product']);
    })
  }
}
