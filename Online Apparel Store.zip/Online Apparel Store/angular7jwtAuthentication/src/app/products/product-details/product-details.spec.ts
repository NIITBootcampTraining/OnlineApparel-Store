import{async,ComponentFixture,TestBed, inject} from '@angular/core/testing';
import{ProductDetailsComponent} from './product-detail.component';
import {RouterTestingModule} from '@angular/router/testing';
import { HttpClientModule } from '@angular/common/http';
import { ProductService } from 'src/app/_services/product.service';
import { ReactiveFormsModule } from '@angular/forms';
describe('Testing Product-Details Component', () => {
    let component: ProductDetailsComponent;
    let fixture: ComponentFixture<ProductDetailsComponent>;
    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [ProductDetailsComponent],
            imports: [RouterTestingModule,HttpClientModule,ReactiveFormsModule],
            providers: [ProductService]
        }).compileComponents();
    }));
    beforeEach(()=>{
        fixture = TestBed.createComponent(ProductDetailsComponent);
        component = fixture.componentInstance;
    })
    it('should create', async(() => {     
        expect(component).toBeTruthy();
    }));
    it('Retrieves Product by ID',async(inject([ProductService],(productServie)=>{
        productServie.getProductsById(1).subscribe(result=>{           
            console.log("Product with ID 1");
            
       })  
   })));
})
