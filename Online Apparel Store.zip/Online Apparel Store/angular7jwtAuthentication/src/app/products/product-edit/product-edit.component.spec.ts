import{async,ComponentFixture,TestBed, inject} from '@angular/core/testing';
import{ProductEditComponent} from './product-edit.component';
import {RouterTestingModule} from '@angular/router/testing';
import { HttpClientModule } from '@angular/common/http';
import { ProductService } from 'src/app/_services/product.service';
import { ReactiveFormsModule } from '@angular/forms';
import { Product } from 'src/app/_models/product';
describe('Testing Product-Edit Component', () => {
    let component: ProductEditComponent;
    let fixture: ComponentFixture<ProductEditComponent>;
    let pro:Product =new Product()
    {
        pro.productId=10,
        pro.productName="shoessss",
        pro.productPrice=300,
        pro.productQuantity=200,
        pro.productSize="M",
        pro.vendorId=1,
        pro.categoryId=2,
        pro.brandId=2,
        pro.productDescription="abc",
        pro.productImage="qwerty"
    };
    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [ProductEditComponent],
            imports: [RouterTestingModule,HttpClientModule,ReactiveFormsModule],
            providers: [ProductService]
        }).compileComponents();
    }));
    beforeEach(()=>{
        fixture = TestBed.createComponent(ProductEditComponent);
        component = fixture.componentInstance;
    })
    it('should create', async(() => {     
        expect(component).toBeTruthy();
    }));
    //    it('Edit Product',async(inject([ProductService],(productServie)=>{
    //     productServie.editProduct(10,pro).subscribe(result=>{         
    //        console.log("Product Updated successfully");          
    //      })  
    // })));
})
