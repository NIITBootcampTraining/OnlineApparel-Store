import{async,ComponentFixture,TestBed, inject} from '@angular/core/testing';
import{ProductComponent} from './product.component';
import {RouterTestingModule} from '@angular/router/testing';
import { HttpClientModule } from '@angular/common/http';
import { ProductService } from 'src/app/_services/product.service';
describe('Testing Order Component', () => {
    let component: ProductComponent;
    let fixture: ComponentFixture<ProductComponent>;
    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [ProductComponent],
            imports: [RouterTestingModule,HttpClientModule],
            providers: [ProductService]
        }).compileComponents();
    }));
    beforeEach(()=>{
        fixture = TestBed.createComponent(ProductComponent);
        component = fixture.componentInstance;
    })
    it('should create', async(() => {     
        expect(component).toBeTruthy();
    }));
    it('Retrieves all Products',async(inject([ProductService],(productServie)=>{
        productServie.getProducts().subscribe(result=>{
            expect(result.length).toEqual(5);
            console.log("products retrived successfully");
            
        })  
   })));
//        it('Delete specific Product',async(inject([ProductService],(productServie)=>{
//         productServie.deleteProducts(10).subscribe(result=>{
//             console.log('Product deleted successfully');
            
//         })  
//    })));
})
