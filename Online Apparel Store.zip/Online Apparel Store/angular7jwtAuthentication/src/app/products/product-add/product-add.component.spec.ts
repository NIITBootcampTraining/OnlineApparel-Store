import{async,ComponentFixture,TestBed, inject} from '@angular/core/testing';
import{ProductAddComponent} from './product-add.component';
import {RouterTestingModule} from '@angular/router/testing';
import { HttpClientModule } from '@angular/common/http';
import { ProductService } from 'src/app/_services/product.service';
import { ReactiveFormsModule } from '@angular/forms';
import { Product } from 'src/app/_models/product';
describe('Testing Product-Add Component', () => {
    let component: ProductAddComponent;
    let fixture: ComponentFixture<ProductAddComponent>;
    let pro:Product =new Product()
    {
        pro.productName="shoes",
        pro.productPrice=300,
        pro.productQuantity=200,
        pro.productSize="M",
        pro.vendorId=1,
        pro.categoryId=2,
        pro.brandId=2,
        pro.productDescription="abc",
        pro.productImage="qwerty"
    };
    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [ProductAddComponent],
            imports: [RouterTestingModule,HttpClientModule,ReactiveFormsModule],
            providers: [ProductService]
        }).compileComponents();
    }));
    beforeEach(()=>{
        fixture = TestBed.createComponent(ProductAddComponent);
        component = fixture.componentInstance;
    })
    it('should create', async(() => {     
        expect(component).toBeTruthy();
    }));
    //    it('Add New Product',async(inject([ProductService],(productServie)=>{
    //     productServie.addNewProduct(pro).subscribe(result=>{         
    //         console.log("Product Added successfully");          
    //       })  
    //  })));
})
