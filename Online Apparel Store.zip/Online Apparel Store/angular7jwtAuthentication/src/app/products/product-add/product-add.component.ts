import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ProductService } from 'src/app/_services/product.service';
import { VendorService } from 'src/app/_services/vendor.service';
import { BrandService } from 'src/app/_services/brand.service';
import { CategoryService } from 'src/app/_services/category.service';
import { Product } from 'src/app/_models/product';
import { Category } from 'src/app/_models/category';
import { Brand } from 'src/app/_models/brand';
import { Vendor } from 'src/app/_models/vendor';

@Component({
  selector: 'app-product-add',
  templateUrl: './product-add.component.html',
  styleUrls: ['./product-add.component.css'],
  providers:[ProductService,VendorService,BrandService,CategoryService]
})
export class ProductAddComponent implements OnInit {
  
  product:Product = new Product();
  proForm:FormGroup;
  category:Category[];
  brand:Brand[];
   vendor:Vendor[];

  constructor(private _pr:ProductService,private router:Router,private _category:CategoryService,private _brand:BrandService,private _vendor:VendorService,private fb:FormBuilder) {
    this.createForm();
   }

  ngOnInit() {  
    this._category.getCategories().subscribe(result=>{
      console.log(result);
      this.category=result;});

      this._brand.getBrands().subscribe(result=>{
        console.log(result);
        this.brand=result;});
      
      this._vendor.getVendors().subscribe(result=>{
        console.log(result);
        this.vendor=result;});
  }
  addNewProduct(){
    this._pr.addNewProduct(this.product).subscribe(result =>{
      console.log(result);
      console.log('Product Added Successfully.');
      this.router.navigate(['/product']);
    });
  }
createForm(){
  this.proForm=this.fb.group({
    productName:['',Validators.required],
    productDescription:['',Validators.required],
    productPrice:['',Validators.required],
    productImage:['',Validators.required],
    productSize:['',Validators.required],
    productQuantity:['',Validators.required],
    brandId:['',Validators.required],
    vendorId:['',Validators.required],
    categoryId:['',Validators.required]
})
}
}

