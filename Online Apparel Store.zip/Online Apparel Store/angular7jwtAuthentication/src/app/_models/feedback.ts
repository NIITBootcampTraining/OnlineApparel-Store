export class Feedback {
    feedbackId:number;
    customerId:number;
    message:string;
}
