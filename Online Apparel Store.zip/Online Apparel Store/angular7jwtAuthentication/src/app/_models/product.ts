export class Product {
    productId:number;
    productName:string;
    productPrice:number;
    productImage:string;
    productQuantity:number;
    productSize:string;
    productDescription:string;
    brandId:number;
    categoryId:number;
    vendorId:number;
}
