export class Brand {
        brandId:number;
        brandName:string;
        brandDescription:string;  
}
