export class manager{
    managerId:number;
    managerFirstName:string;
    managerLastName:string;
    managerPassword:string;
    managerEmail:string;
    managerAddress:string;
    managerCountry:string;
    managerState:string;
    managerZipCode:number;
    managerPhoneNumber:number;
}