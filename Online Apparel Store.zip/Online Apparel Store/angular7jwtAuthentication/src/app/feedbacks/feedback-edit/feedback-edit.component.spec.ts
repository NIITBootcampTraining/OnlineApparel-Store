import{async,ComponentFixture,TestBed} from '@angular/core/testing';
import{FeedbackEditComponent} from './feedback-edit.component';
import {RouterTestingModule} from '@angular/router/testing';
import { HttpClientModule } from '@angular/common/http';
import { ReactiveFormsModule } from '@angular/forms';
describe('Testing FeedBack-Edit Component', () => {
    let component: FeedbackEditComponent;
    let fixture: ComponentFixture<FeedbackEditComponent>;
    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [FeedbackEditComponent],
            imports: [RouterTestingModule,HttpClientModule,ReactiveFormsModule],
            providers: []
        }).compileComponents();
    }));
    beforeEach(()=>{
        fixture = TestBed.createComponent(FeedbackEditComponent);
        component = fixture.componentInstance;
    })
    it('should create', async(() => {     
        expect(component).toBeTruthy();
    }));
})
