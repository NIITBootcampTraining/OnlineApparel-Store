import{async,ComponentFixture,TestBed} from '@angular/core/testing';
import{FeedbackAddComponent} from './feedback-add.component';
import {RouterTestingModule} from '@angular/router/testing';
import { HttpClientModule } from '@angular/common/http';
import { ReactiveFormsModule } from '@angular/forms';
describe('Testing FeedBack-Add Component', () => {
    let component: FeedbackAddComponent;
    let fixture: ComponentFixture<FeedbackAddComponent>;
    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [FeedbackAddComponent],
            imports: [RouterTestingModule,HttpClientModule,ReactiveFormsModule],
            providers: []
        }).compileComponents();
    }));
    beforeEach(()=>{
        fixture = TestBed.createComponent(FeedbackAddComponent);
        component = fixture.componentInstance;
    })
    it('should create', async(() => {     
        expect(component).toBeTruthy();
    }));
})
