import { Component, OnInit } from '@angular/core';
import { FeedbackService } from 'src/app/_services/feedback.service';
import { ActivatedRoute } from '@angular/router';
import { Feedback } from 'src/app/_models/feedback';
import { CustomerService } from 'src/app/_services/customer.service';
import { Customer } from 'src/app/_models/customer';

@Component({
  selector: 'app-feedback-details',
  templateUrl: './feedback-details.component.html',
  styleUrls: ['./feedback-details.component.css'],
  providers:[FeedbackService,CustomerService]
})
export class FeedbackDetailsComponent implements OnInit {

  id:number;
  feedback:Feedback = new Feedback();
  cus:Customer;
  constructor(private route: ActivatedRoute, private fed: FeedbackService,private _cus:CustomerService) { }

  ngOnInit() {
    this.route.params.subscribe(param => {
      this.id = +param['id'];
      this.fed.getFeedBackById(this.id).subscribe(result => {
        this.feedback = result;
        console.log(result);
        this._cus.getCustomerById(this.feedback.customerId).subscribe(res=>{
          this.cus=res;
        })
      })
    });
  }

}
