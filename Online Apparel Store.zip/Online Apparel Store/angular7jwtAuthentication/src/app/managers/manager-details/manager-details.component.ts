import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { manager } from 'src/app/_models/manager';
import { ManagerService } from 'src/app/_services/manager.services';

@Component({
  selector: 'app-manager-detail',
  templateUrl: './manager-details.component.html',
  providers: [ManagerService]
})
export class managerDetailsComponent implements OnInit {

  id: number;
  brand: manager = new manager();
  constructor(private route: ActivatedRoute, private br: ManagerService,private router:Router) { }

  ngOnInit() {
    this.route.params.subscribe(param => {
      this.id = +param['id'];
      this.br.getManagerById(this.id).subscribe(result => {
        this.brand = result;
        console.log(result);
      })
    });
  }
  deleteExistingBrand(id: number) {
    this.br.deleteManager(id).subscribe(result => {
      console.log("Mananger Deleted Successfully");
      this.router.navigate(['/manager']);
    })
  }
}
