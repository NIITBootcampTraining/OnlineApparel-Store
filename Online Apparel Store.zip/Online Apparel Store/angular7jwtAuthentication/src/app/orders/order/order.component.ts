import { Component, OnInit } from '@angular/core';
import { OrderService } from 'src/app/_services/order.service';
import { Order } from 'src/app/_models/order';

@Component({
  selector: 'app-order',
  templateUrl: './order.component.html',
  styleUrls: ['./order.component.css'],
  providers:[OrderService]
})
export class OrderComponent implements OnInit {

  order:Order[];
  constructor(private _order: OrderService) { }

  ngOnInit() {
    this.getAllOrder()
  }
  getAllOrder() {
    this._order.getOrder().subscribe(result => {
      this.order = result;
      console.log(this.order);
    })
  }
  deleteExistingOrder(id: number) {
    this._order.deleteOrder(id).subscribe(result => {
      console.log("Order Deleted Successfully");
      this.getAllOrder() ;

    })
  }

}
