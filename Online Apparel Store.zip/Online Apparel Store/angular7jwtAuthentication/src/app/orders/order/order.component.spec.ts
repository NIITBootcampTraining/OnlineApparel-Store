import{async,ComponentFixture,TestBed, inject} from '@angular/core/testing';
import{OrderComponent} from './order.component';
import {RouterTestingModule} from '@angular/router/testing';
import { HttpClientModule } from '@angular/common/http';
import { OrderService } from 'src/app/_services/order.service';
describe('Testing Order Component', () => {
    let component: OrderComponent;
    let fixture: ComponentFixture<OrderComponent>;
    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [OrderComponent],
            imports: [RouterTestingModule,HttpClientModule],
            providers: [OrderService]
        }).compileComponents();
    }));
    beforeEach(()=>{
        fixture = TestBed.createComponent(OrderComponent);
        component = fixture.componentInstance;
    })
    it('should create', async(() => {     
        expect(component).toBeTruthy();
    }));
    it('Retrieves all Orders',async(inject([OrderService],(orderServie)=>{
        orderServie.getOrder().subscribe(result=>{
            expect(result.length).toEqual(7);
        })  
   })));
//        it('Delete specific Order',async(inject([OrderService],(orderServie)=>{
//         orderServie.deleteOrder(8).subscribe(result=>{
//             console.log('Order deleted successfully');
            
//         })  
//    })));
})
