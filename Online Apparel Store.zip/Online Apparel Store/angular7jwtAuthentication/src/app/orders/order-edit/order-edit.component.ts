import { Component, OnInit } from '@angular/core';
import { OrderService } from 'src/app/_services/order.service';
import { Order } from 'src/app/_models/order';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-order-edit',
  templateUrl: './order-edit.component.html',
  styleUrls: ['./order-edit.component.css'],
  providers:[OrderService]
})
export class OrderEditComponent implements OnInit {

  id: number;
  order:Order=new Order();
  catEditForm:FormGroup;
  constructor(private _or: OrderService, private route: ActivatedRoute,private router:Router,private fb:FormBuilder) {
    this.editForm();
   }

  ngOnInit() {
    this.route.params.subscribe(param => {
      this.id = +param['id'];
      this._or.getOrderById(this.id).subscribe(result => {
        this.order = result;
      })
    })
  }
  editExistingOrder() {
    this._or.editOrder(this.id, this.order).subscribe(result => {
      console.log('Updated Successfully');
      this.router.navigate(['/order'])
    });
  }
  editForm(){
    this.catEditForm=this.fb.group({
      orderDate:['',Validators.required],
      orderAmount:['',Validators.required]
    })
  }
}
