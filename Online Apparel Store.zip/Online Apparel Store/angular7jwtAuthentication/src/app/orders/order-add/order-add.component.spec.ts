import{async,ComponentFixture,TestBed, inject} from '@angular/core/testing';
import{OrderAddComponent} from './order-add.component';
import {RouterTestingModule} from '@angular/router/testing';
import { HttpClientModule } from '@angular/common/http';
import { ReactiveFormsModule } from '@angular/forms';
import { OrderService } from 'src/app/_services/order.service';
describe('Testing Order-Add Component', () => {
    let component: OrderAddComponent;
    let fixture: ComponentFixture<OrderAddComponent>;
    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [OrderAddComponent],
            imports: [RouterTestingModule,HttpClientModule,ReactiveFormsModule],
            providers: []
        }).compileComponents();
    }));
    beforeEach(()=>{
        fixture = TestBed.createComponent(OrderAddComponent);
        component = fixture.componentInstance;
    })
    it('should create', async(() => {     
        expect(component).toBeTruthy();
    }));
})
