import { Component, OnInit } from '@angular/core';
import { paymentService } from 'src/app/_services/payment.service';
import { payment } from 'src/app/_models/payment';

@Component({
  selector: 'app-payment',
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.css'],
  providers: [paymentService]
})
export class paymentComponent implements OnInit {

  brands: payment[];
  constructor(private _brands: paymentService) { }

  ngOnInit() {
    this.getAllManagers()
  }
  getAllManagers() {
    this._brands.getAdmin().subscribe(result => {
      this.brands = result;
      console.log(this.brands);
    })
  }

}
