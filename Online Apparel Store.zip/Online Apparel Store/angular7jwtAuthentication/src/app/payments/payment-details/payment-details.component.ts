import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { paymentService } from 'src/app/_services/payment.service';
import { payment } from 'src/app/_models/payment';

@Component({
  selector: 'app-payment-detail',
  templateUrl: './payment-details.component.html',
  providers: [paymentService]
})
export class paymentDetailsComponent implements OnInit {

  id: number;
  brand: payment = new payment();
  constructor(private route: ActivatedRoute, private br: paymentService,private router:Router) { }

  ngOnInit() {
    this.route.params.subscribe(param => {
      this.id = +param['id'];
      this.br.getAdminById(this.id).subscribe(result => {
        this.brand = result;
        console.log(result);
      })
    });
  }

}
