import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';

// used to create fake backend
import { fakeBackendProvider } from './_helpers';

import { AppComponent } from './app.component';
import { routing } from './app.routing';

import { JwtInterceptor, ErrorInterceptor } from './_helpers';
import { HomeComponent } from './home';
import { LoginComponent } from './login';
import { AboutComponent } from './about/about.component';
import { BrandComponent } from './brands/brand/brand.component';
import { BrandAddComponent } from './brands/brand-add/brand-add.component';
import { BrandEditComponent } from './brands/brand-edit/brand-edit.component';
import { BrandDetailsComponent } from './brands/brand-details/brand-detail.component';
import { CategoryComponent } from './categories/category/category.component';
import { CategoryAddComponent } from './categories/category-add/category-add.component';
import { CategoryEditComponent } from './categories/category-edit/category-edit.component';
import { CategoryDetailsComponent } from './categories/category-details/category-detail.component';
import { VendorComponent } from './vendors/vendor/vendor.component';
import { VendorAddComponent } from './vendors/vendor-add/vendor-add.component';
import { VendorEditComponent } from './vendors/vendor-edit/vendor-edit.component';
import { VendorDetailsComponent } from './vendors/vendor-details/vendor-detail.component';
import { ProductComponent } from './products/product/product.component';
import { ProductAddComponent } from './products/product-add/product-add.component';
import { ProductEditComponent } from './products/product-edit/product-edit.component';
import { ProductDetailsComponent } from './products/product-details/product-detail.component';
import { OrderAddComponent } from './orders/order-add/order-add.component';
import { OrderDetailsComponent } from './orders/order-details/order-details.component';
import { OrderEditComponent } from './orders/order-edit/order-edit.component';
import { CustomerAddComponent } from './customers/customer-add/customer-add.component';
import { CustomerDetailsComponent } from './customers/customer-details/customer-details.component';
import { CustomerEditComponent } from './customers/customer-edit/customer-edit.component';
import { FeedbackAddComponent } from './feedbacks/feedback-add/feedback-add.component';
import { FeedbackEditComponent } from './feedbacks/feedback-edit/feedback-edit.component';
import { FeedbackDetailsComponent } from './feedbacks/feedback-details/feedback-details.component';
import { FeedbackComponent } from './feedbacks/feedback/feedback.component';
import { OrderComponent } from './orders/order/order.component';
import { CustomerComponent } from './customers/customer/customer.component';
import { ManagerAddComponent } from './managers/manager-add/manager-add.component';
import { managerEditComponent } from './managers/manager-edit/manager-edit.component';
import { ManagerComponet } from './managers/manager/manager.component';
import { managerDetailsComponent } from './managers/manager-details/manager-details.component';
import { paymentComponent } from './payments/payment/payment.component';
import { paymentDetailsComponent } from './payments/payment-details/payment-details.component';


@NgModule({
    imports: [
        BrowserModule,
        ReactiveFormsModule,
        HttpClientModule,
        routing
    ],
    declarations: [
        AppComponent,
        HomeComponent,
        LoginComponent,
        AboutComponent,
        BrandComponent,
        BrandAddComponent,
        BrandEditComponent,
        BrandDetailsComponent,
        CategoryComponent,
        CategoryAddComponent,
        CategoryEditComponent,
        CategoryDetailsComponent,
        VendorComponent,
        VendorAddComponent,
        VendorEditComponent,
        VendorDetailsComponent,
        ProductComponent,
        ProductAddComponent,
        ProductEditComponent,
        ProductDetailsComponent,
        OrderComponent,  
        OrderAddComponent,
        OrderDetailsComponent,
        OrderEditComponent,
        CustomerComponent,
        CustomerAddComponent,
        CustomerDetailsComponent,
        CustomerEditComponent,
        FeedbackComponent,
        FeedbackAddComponent,
        FeedbackEditComponent,
        FeedbackDetailsComponent,
        ManagerComponet,
        ManagerAddComponent,
        managerDetailsComponent,
        managerEditComponent,
        paymentComponent,
        paymentDetailsComponent

    ],
    providers: [
        { provide: HTTP_INTERCEPTORS, useClass: JwtInterceptor, multi: true },
        { provide: HTTP_INTERCEPTORS, useClass: ErrorInterceptor, multi: true },

        // provider used to create fake backend
        fakeBackendProvider,
        FormsModule,
        ReactiveFormsModule,
        HttpClientModule,
        
    ],
    bootstrap: [AppComponent]
})

export class AppModule { }