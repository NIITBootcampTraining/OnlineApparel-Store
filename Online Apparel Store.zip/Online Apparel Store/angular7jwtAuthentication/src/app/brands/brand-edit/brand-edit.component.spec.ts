import{async,ComponentFixture,TestBed, inject} from '@angular/core/testing';
import{BrandEditComponent} from './brand-edit.component';
import {RouterTestingModule} from '@angular/router/testing';
import { HttpClientModule } from '@angular/common/http';
import { ReactiveFormsModule } from '@angular/forms';
import { BrandService } from 'src/app/_services/brand.service';
import { Brand } from 'src/app/_models/brand';
describe('Testing Brand-Edit Component', () => {
    let component: BrandEditComponent;
    let fixture: ComponentFixture<BrandEditComponent>;
    let brand:Brand =new Brand()
    {
        brand.brandId=5;
        brand.brandName="Nike";
        brand.brandDescription="Nikeee Desc";
    }; 
    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [BrandEditComponent],
            imports: [RouterTestingModule,HttpClientModule,ReactiveFormsModule],
            providers: [BrandService]
        }).compileComponents();
    }));
    beforeEach(()=>{
        fixture = TestBed.createComponent(BrandEditComponent);
        component = fixture.componentInstance;
    })
    it('should create', async(() => {     
        expect(component).toBeTruthy();
    }));
    // it('Edit Brand',async(inject([BrandService],(brandServie)=>{
    //     brandServie.editBrand(5,brand).subscribe(result=>{         
    //        console.log("Brand Updated successfully");          
    //      })  
    // })));
})
