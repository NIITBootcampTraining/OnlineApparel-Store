import{async,ComponentFixture,TestBed, inject} from '@angular/core/testing';
import{BrandDetailsComponent} from './brand-detail.component';
import {RouterTestingModule} from '@angular/router/testing';
import { HttpClientModule } from '@angular/common/http';
import { ReactiveFormsModule } from '@angular/forms';
import { BrandService } from 'src/app/_services/brand.service';
describe('Testing Brand-Details Component', () => {
    let component: BrandDetailsComponent;
    let fixture: ComponentFixture<BrandDetailsComponent>;
    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [BrandDetailsComponent],
            imports: [RouterTestingModule,HttpClientModule,ReactiveFormsModule],
            providers: [BrandService]
        }).compileComponents();
    }));
    beforeEach(()=>{
        fixture = TestBed.createComponent(BrandDetailsComponent);
        component = fixture.componentInstance;
    })
    it('should create', async(() => {     
        expect(component).toBeTruthy();
    }));
     it('Retrieves Brand by ID',async(inject([BrandService],(brandServie)=>{
          brandServie.getBrandsById(5).subscribe(result=>{           
              console.log("Brand with ID 5");
              
         })  
     })));
})
