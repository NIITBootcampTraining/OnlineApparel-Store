import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { BrandService } from 'src/app/_services/brand.service';
import { Brand } from 'src/app/_models/brand';

@Component({
  selector: 'app-brand-detail',
  templateUrl: './brand-detail.component.html',
  styleUrls: ['./brand-detail.component.css'],
  providers: [BrandService]
})
export class BrandDetailsComponent implements OnInit {

  id: number;
  brand: Brand = new Brand();
  constructor(private route: ActivatedRoute, private br: BrandService,private router:Router) { }

  ngOnInit() {
    this.route.params.subscribe(param => {
      this.id = +param['id'];
      this.br.getBrandsById(this.id).subscribe(result => {
        this.brand = result;
        console.log(result);
      })
    });
  }
  deleteExistingBrand(id: number) {
    this.br.deleteBrands(id).subscribe(result => {
      console.log("Brand Deleted Successfully");
      this.router.navigate(['/brand']);
    })
  }
}
