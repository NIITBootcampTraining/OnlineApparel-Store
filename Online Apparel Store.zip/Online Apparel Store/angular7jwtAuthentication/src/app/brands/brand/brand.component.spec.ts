import{async,ComponentFixture,TestBed, inject} from '@angular/core/testing';
import{BrandComponent} from './brand.component';
import {RouterTestingModule} from '@angular/router/testing';
import { HttpClientModule } from '@angular/common/http';
import { BrandService } from 'src/app/_services/brand.service';
describe('Testing Brand Component', () => {
    let component: BrandComponent;
    let fixture: ComponentFixture<BrandComponent>;
    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [BrandComponent],
            imports: [RouterTestingModule,HttpClientModule],
            providers: [BrandService]
        }).compileComponents();
    }));
    beforeEach(()=>{
        fixture = TestBed.createComponent(BrandComponent);
        component = fixture.componentInstance;
    })
    it('should create', async(() => {     
        expect(component).toBeTruthy();
    }));
    // it('Retrieves all Brands',async(inject([BrandService],(brandServie)=>{
    //      brandServie.getBrands().subscribe(result=>{
    //          expect(result.length).toEqual(3);
    //      })  
    // })));
//     it('Delete specific Brand',async(inject([BrandService],(brandServie)=>{
//         brandServie.deleteBrands(3).subscribe(result=>{
//             console.log('Brand deleted successfully');
            
//         })  
//    })));
});
