# angular7jwtAuthentication
This is angular Admin API.
